
    var config = {
        mode: "fixed_servers",
        rules: {
          singleProxy: { scheme: "http", host: "dc.decodo.com", port: parseInt(10002) },
          bypassList: ["localhost"]
        }
    };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    function callbackFn(details) {
        return { authCredentials: { username: "sp8s7h0c08", password: "JiRq_amsv5J95x7yOw" } };
    }
    chrome.webRequest.onAuthRequired.addListener(
        callbackFn, {urls: ["<all_urls>"]}, ['blocking']
    );
    